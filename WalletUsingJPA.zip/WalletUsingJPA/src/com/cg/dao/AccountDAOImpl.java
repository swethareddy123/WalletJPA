package com.cg.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.dto.Customer;
import com.cg.exception.AccountException;

public class AccountDAOImpl implements AccountDAO{

	EntityManager manager;
	
	public AccountDAOImpl(){
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
		manager = emf.createEntityManager();
		
	}
	
	@Override
	public void createAccount(Customer customer) {
		
		manager.getTransaction().begin();
		manager.persist(customer);
		manager.getTransaction().commit();
		
	}

	@Override
	public void deposit(String mobileNo, double amount) {
		
		
		manager.getTransaction().begin();
		
		Customer cust =  manager.find(Customer.class, mobileNo);
		double amt = cust.getInitialBalance();
		amt += amount;
		System.out.println(amt);
		cust.setInitialBalance(amt);
		
		manager.getTransaction().commit();
		
		
		
	}
	
	
	@Override
	public void withdraw(String mobileNo, double withdrawAmount) {
		
		
		manager.getTransaction().begin();
		boolean flag = false;
		Customer cust = manager.find(Customer.class, mobileNo);
		double amount = cust.getInitialBalance();
		if(!(amount-withdrawAmount > 500)){
			System.err.println("Insufficient Balance.\nPlease try again");
			cust.setInitialBalance(amount);
		}
		else{
			amount -= withdrawAmount;
			cust.setInitialBalance(amount);
			System.out.println("Rs."+withdrawAmount+" withdrawn successfully");
			flag = true;			
		}
		manager.getTransaction().commit();
		
		
	}
	


	@Override
	public double checkBalance(String mobileNo) {
		
		manager.getTransaction().begin();
		
		Customer cust = manager.find(Customer.class, mobileNo);
		double amount = cust.getInitialBalance();
		manager.getTransaction().commit();
		
		return amount;
		
	}
	@Override
	public void fundTransfer(String sender, String reciever, double amount) {
		
		
		manager.getTransaction().begin();
		boolean flag = false;
		Customer custSender = manager.find(Customer.class, sender);
		Customer custreciever = manager.find(Customer.class, reciever);
		
		double senderAmount = custSender.getInitialBalance();
		double recieverAmount = custreciever.getInitialBalance();
		
		if((senderAmount - amount) > 500){
			senderAmount -= amount;
			recieverAmount += amount;
			custreciever.setInitialBalance(recieverAmount);
			custSender.setInitialBalance(senderAmount);
			flag = true;
			System.out.println("Fund of Rs."+amount+" transferred successfully! from "+custSender.getName()+" to "+custreciever.getName());
		}else{
			
			System.err.println("Invalid amount! As transfer amount is greater than your account balance.");
		}
		
		manager.getTransaction().commit();
		
		
			
	}
	
	@Override
	public boolean validateAccount(String mobileNo) throws AccountException {
		
		Customer customer = manager.find(Customer.class, mobileNo);
		if(customer == null)
			return false;
		return true;
	}
	
}
