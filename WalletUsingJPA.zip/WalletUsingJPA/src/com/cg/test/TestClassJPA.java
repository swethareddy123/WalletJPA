package com.cg.test;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import com.cg.exception.AccountException;
import com.cg.service.AccountService;
import com.cg.service.AccountServiceImpl;

public class TestClassJPA {

	
    
    @Test
    public void test_validateName_v1() throws AccountException{                                 //Name should not contain numbers.
    
        String name="Swetha";
        AccountService service=new AccountServiceImpl();
        boolean result= service.validateName(name);
        Assert.assertEquals(false,result);
    }
    @Test
    public void test_validateName_v2() throws AccountException{                                 //Name should start with CAPS and have all other letters in
                                                                                                    // small with at least 3 letters and at most 10.
        String name="Swetha";                                    
        AccountService service=new AccountServiceImpl();
        boolean result= service.validateName(name);
        Assert.assertEquals(true,result);
    }
    @Test
    public void test_validateName_v3() throws AccountException{                                  //Name should not start with a small letter.
    
        String name="Swetha";
        AccountService service=new AccountServiceImpl();
        boolean result= service.validateName(name);
        Assert.assertEquals(false,result);
    }
    
    @Test
    public void test_validateMobNo_v1() throws AccountException{                                  //Mobile Number should not contain letters.
    
        String mobNo="zxcv91678905";
        AccountService service=new AccountServiceImpl();
        boolean result= service.validateMoileNo(mobNo);
        Assert.assertEquals(false,result);
    }
    @Test
    public void test_validateMobNo_v2() throws AccountException{                                 //Mobile Number should contain only digits and should be
                                                                                                     //of length 10.
        String mobNo="8179323885";
        AccountService service=new AccountServiceImpl();
        boolean result= service.validateMoileNo(mobNo);
        Assert.assertEquals(true,result);
    }
    @Test
    public void test_validateMobNo_v3() throws AccountException{                                     //Mobile Number should not be less than 10 digits.
    
        String mobNo="987654";
        AccountService service=new AccountServiceImpl();
        boolean result= service.validateMoileNo(mobNo);
        Assert.assertEquals(false,result);
    }
    @Test
    public void test_validateMobNo_v4() throws AccountException{
    	                                                                                      //Mobile Number should not start with 0.
        String mobNo="096834164";
        AccountService service=new AccountServiceImpl();
        boolean result= service.validateMoileNo(mobNo);
        Assert.assertEquals(false,result);
    }

}
